# for development
#use Devel::Cover ('+select' => 'CGI/Application/Dispatch', '+silent');

1;



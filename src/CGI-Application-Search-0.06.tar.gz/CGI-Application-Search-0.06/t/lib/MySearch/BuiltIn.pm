package MySearch::BuiltIn;
use base 'MySearch';

# don't do anything yet, but we might want to later

1;

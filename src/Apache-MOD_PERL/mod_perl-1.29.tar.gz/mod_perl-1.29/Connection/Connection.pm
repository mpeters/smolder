package Apache::Connection;

use mod_perl ();

$VERSION = '1.00';
__PACKAGE__->mod_perl::boot($VERSION);

1;
__END__

# WARNING: this file is generated, do not edit
# generated on Fri Sep  1 18:25:25 2006
# 01: /usr/local/lib/perl5/site_perl/5.8.8/i686-linux/Apache/TestConfig.pm:944
# 02: /usr/local/lib/perl5/site_perl/5.8.8/i686-linux/Apache/TestConfig.pm:962
# 03: /usr/local/lib/perl5/site_perl/5.8.8/i686-linux/Apache/TestConfig.pm:1844
# 04: /usr/local/lib/perl5/site_perl/5.8.8/i686-linux/Apache/TestRun.pm:508
# 05: /usr/local/lib/perl5/site_perl/5.8.8/i686-linux/Apache/TestRun.pm:725
# 06: /usr/local/lib/perl5/site_perl/5.8.8/i686-linux/Apache/TestRun.pm:725
# 07: /home/mpeters/mod_auth_tkt-2.0.0rc1/t/TEST:7

package apache_test_config;

sub new {
    bless( {
                 'verbose' => undef,
                 'hostport' => 'localhost.localdomain:8529',
                 'clean_level' => 1,
                 'postamble' => [
                                  '<IfModule mod_mime.c>
    TypesConfig "/home/mpeters/repos/smolder/apache/conf/mime.types"
</IfModule>
',
                                  'Include "/home/mpeters/mod_auth_tkt-2.0.0rc1/t/conf/extra.conf"',
                                  ''
                                ],
                 'mpm' => '',
                 'inc' => [],
                 'APXS' => '/home/mpeters/development/smolder/apache/bin/apxs',
                 '_apxs' => {
                              'LIBEXECDIR' => '/home/mpeters/repos/smolder/apache/libexec',
                              'SYSCONFDIR' => '/home/mpeters/repos/smolder/apache/conf',
                              'TARGET' => 'httpd',
                              'PREFIX' => '/home/mpeters/repos/smolder/apache',
                              'SBINDIR' => '/home/mpeters/repos/smolder/apache/bin'
                            },
                 'save' => 1,
                 'vhosts' => {
                               'VHostLocalSecret' => {
                                                       'hostport' => 'localhost.localdomain:8530',
                                                       'servername' => 'localhost.localdomain',
                                                       'name' => 'localhost.localdomain:8530',
                                                       'port' => 8530,
                                                       'namebased' => 0
                                                     },
                               'VHostGlobalSecret' => {
                                                        'hostport' => 'localhost.localdomain:8531',
                                                        'servername' => 'localhost.localdomain',
                                                        'name' => 'localhost.localdomain:8531',
                                                        'port' => 8531,
                                                        'namebased' => 0
                                                      }
                             },
                 'httpd_basedir' => '/home/mpeters/repos/smolder/apache',
                 'server' => bless( {
                                      'run' => bless( {
                                                        'conf_opts' => {
                                                                         'verbose' => undef,
                                                                         'save' => 1,
                                                                         'apxs' => '/home/mpeters/development/smolder/apache/bin/apxs'
                                                                       },
                                                        'test_config' => $VAR1,
                                                        'tests' => [],
                                                        'opts' => {
                                                                    'breakpoint' => [],
                                                                    'postamble' => [],
                                                                    'preamble' => [],
                                                                    'configure' => 1,
                                                                    'req_args' => {},
                                                                    'header' => {}
                                                                  },
                                                        'argv' => [],
                                                        'server' => $VAR1->{'server'}
                                                      }, 'MAT::TestRun' ),
                                      'port_counter' => 8531,
                                      'mpm' => '',
                                      'version' => 'Apache/1.3.36',
                                      'rev' => '1',
                                      'name' => 'localhost.localdomain:8529',
                                      'config' => $VAR1
                                    }, 'Apache::TestServer' ),
                 'postamble_hooks' => [
                                        sub { "DUMMY" }
                                      ],
                 'inherit_config' => {
                                       'ServerRoot' => '/home/mpeters/repos/smolder/apache',
                                       'ServerAdmin' => 'mpeters@localhost.localdomain',
                                       'TypesConfig' => '/home/mpeters/repos/smolder/apache/conf/mime.types',
                                       'DocumentRoot' => '/home/mpeters/repos/smolder/apache/htdocs',
                                       'LoadModule' => [
                                                         [
                                                           'mime_magic_module',
                                                           'libexec/mod_mime_magic.so'
                                                         ],
                                                         [
                                                           'rewrite_module',
                                                           'libexec/mod_rewrite.so'
                                                         ],
                                                         [
                                                           'proxy_module',
                                                           'libexec/libproxy.so'
                                                         ],
                                                         [
                                                           'unique_id_module',
                                                           'libexec/mod_unique_id.so'
                                                         ]
                                                       ]
                                     },
                 'cmodules_disabled' => {},
                 'preamble_hooks' => [
                                       sub { "DUMMY" }
                                     ],
                 'preamble' => [
                                 '<IfModule !mod_mime_magic.c>
    LoadModule mime_magic_module "/home/mpeters/repos/smolder/apache/libexec/mod_mime_magic.so"
</IfModule>
',
                                 '<IfModule !mod_rewrite.c>
    LoadModule rewrite_module "/home/mpeters/repos/smolder/apache/libexec/mod_rewrite.so"
</IfModule>
',
                                 '<IfModule !mod_proxy.c>
    LoadModule proxy_module "/home/mpeters/repos/smolder/apache/libexec/libproxy.so"
</IfModule>
',
                                 '<IfModule !mod_unique_id.c>
    LoadModule unique_id_module "/home/mpeters/repos/smolder/apache/libexec/mod_unique_id.so"
</IfModule>
',
                                 ''
                               ],
                 'vars' => {
                             'defines' => '',
                             'VHostGlobalSecret_port' => 8531,
                             'cgi_module_name' => 'mod_cgi',
                             'conf_dir' => '/home/mpeters/repos/smolder/apache/conf',
                             't_conf_file' => '/home/mpeters/mod_auth_tkt-2.0.0rc1/t/conf/httpd.conf',
                             't_dir' => '/home/mpeters/mod_auth_tkt-2.0.0rc1/t',
                             'cgi_module' => 'mod_cgi.c',
                             'target' => 'httpd',
                             'thread_module' => 'worker.c',
                             'bindir' => '',
                             'user' => 'mpeters',
                             'access_module_name' => 'mod_access',
                             'auth_module_name' => 'mod_auth',
                             'top_dir' => '/home/mpeters/mod_auth_tkt-2.0.0rc1',
                             'httpd_conf' => '/home/mpeters/repos/smolder/apache/conf/httpd.conf',
                             'httpd' => '/home/mpeters/repos/smolder/apache/bin/httpd',
                             'scheme' => 'http',
                             'ssl_module_name' => 'mod_ssl',
                             'port' => 8529,
                             'sbindir' => '/home/mpeters/repos/smolder/apache/bin',
                             't_conf' => '/home/mpeters/mod_auth_tkt-2.0.0rc1/t/conf',
                             'VHostLocalSecret_port' => 8530,
                             'servername' => 'localhost.localdomain',
                             'inherit_documentroot' => '/home/mpeters/repos/smolder/apache/htdocs',
                             'proxy' => 'off',
                             'serveradmin' => 'mpeters@localhost.localdomain',
                             'remote_addr' => '127.0.0.1',
                             'perlpod' => '/usr/local/lib/perl5/5.8.8/pod',
                             'sslcaorg' => 'asf',
                             'php_module_name' => 'sapi_apache2',
                             'maxclients_preset' => 0,
                             'php_module' => 'sapi_apache2.c',
                             'ssl_module' => 'mod_ssl.c',
                             'auth_module' => 'mod_auth.c',
                             'access_module' => 'mod_access.c',
                             't_logs' => '/home/mpeters/mod_auth_tkt-2.0.0rc1/t/logs',
                             'minclients' => 1,
                             'maxclients' => 2,
                             'group' => 'mpeters',
                             't_pid_file' => '/home/mpeters/mod_auth_tkt-2.0.0rc1/t/logs/httpd.pid',
                             'apxs' => '/home/mpeters/development/smolder/apache/bin/apxs',
                             'maxclientsthreadedmpm' => 2,
                             'thread_module_name' => 'worker',
                             'documentroot' => '/home/mpeters/mod_auth_tkt-2.0.0rc1/t/htdocs',
                             'serverroot' => '/home/mpeters/mod_auth_tkt-2.0.0rc1/t',
                             'sslca' => '/home/mpeters/mod_auth_tkt-2.0.0rc1/t/conf/ssl/ca',
                             'perl' => '/usr/local/bin/perl',
                             'src_dir' => undef,
                             'proxyssl_url' => ''
                           },
                 'clean' => {
                              'files' => {
                                           '/home/mpeters/mod_auth_tkt-2.0.0rc1/t/conf/apache_test_config.pm' => 1,
                                           '/home/mpeters/mod_auth_tkt-2.0.0rc1/t/conf/extra.conf' => 1,
                                           '/home/mpeters/mod_auth_tkt-2.0.0rc1/t/logs/apache_runtime_status.sem' => 1,
                                           '/home/mpeters/mod_auth_tkt-2.0.0rc1/t/conf/httpd.conf' => 1
                                         },
                              'dirs' => {}
                            },
                 'httpd_info' => {
                                   'BUILT' => 'Sep  1 2006 17:50:16',
                                   'MODULE_MAGIC_NUMBER_MINOR' => '18',
                                   'VERSION' => 'Apache/1.3.36 (Unix)',
                                   'MODULE_MAGIC_NUMBER' => '19990320:18',
                                   'MODULE_MAGIC_NUMBER_MAJOR' => '19990320'
                                 },
                 'modules' => {
                                'mod_include.c' => 1,
                                'mod_headers.c' => 1,
                                'mod_asis.c' => 1,
                                'mod_env.c' => 1,
                                'mod_negotiation.c' => 1,
                                'mod_proxy.c' => '/home/mpeters/repos/smolder/apache/libexec/libproxy.so',
                                'http_core.c' => 1,
                                'mod_setenvif.c' => 1,
                                'mod_access.c' => 1,
                                'mod_dir.c' => 1,
                                'mod_cgi.c' => 1,
                                'mod_actions.c' => 1,
                                'mod_mime_magic.c' => '/home/mpeters/repos/smolder/apache/libexec/mod_mime_magic.so',
                                'mod_so.c' => 1,
                                'mod_perl.c' => 1,
                                'mod_expires.c' => 1,
                                'mod_unique_id.c' => '/home/mpeters/repos/smolder/apache/libexec/mod_unique_id.so',
                                'mod_imap.c' => 1,
                                'mod_alias.c' => 1,
                                'mod_autoindex.c' => 1,
                                'mod_status.c' => 1,
                                'mod_rewrite.c' => '/home/mpeters/repos/smolder/apache/libexec/mod_rewrite.so',
                                'mod_auth.c' => 1,
                                'mod_log_config.c' => 1,
                                'mod_mime.c' => 1,
                                'mod_userdir.c' => 1
                              },
                 'httpd_defines' => {
                                      'SUEXEC_BIN' => '/home/mpeters/repos/smolder/apache/bin/suexec',
                                      'HARD_SERVER_LIMIT' => '256',
                                      'DEFAULT_PIDLOG' => 'logs/httpd.pid',
                                      'HAVE_MMAP' => 1,
                                      'ACCESS_CONFIG_FILE' => 'conf/access.conf',
                                      'DYNAMIC_MODULE_LIMIT' => '64',
                                      'HAVE_SYSVSEM_SERIALIZED_ACCEPT' => 1,
                                      'DEFAULT_SCOREBOARD' => 'logs/httpd.scoreboard',
                                      'RESOURCE_CONFIG_FILE' => 'conf/srm.conf',
                                      'DEFAULT_LOCKFILE' => 'logs/httpd.lock',
                                      'USE_MMAP_FILES' => 1,
                                      'SINGLE_LISTEN_UNSERIALIZED_ACCEPT' => 1,
                                      'HAVE_SHMGET' => 1,
                                      'DEFAULT_ERRORLOG' => 'logs/error_log',
                                      'USE_SHMGET_SCOREBOARD' => 1,
                                      'HTTPD_ROOT' => '/home/mpeters/repos/smolder/apache',
                                      'TYPES_CONFIG_FILE' => 'conf/mime.types',
                                      'HAVE_FCNTL_SERIALIZED_ACCEPT' => 1,
                                      'SERVER_CONFIG_FILE' => 'conf/httpd.conf'
                                    }
               }, 'Apache::TestConfig' );
}

1;

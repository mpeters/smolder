package MyApp::Module::Name;
use base 'CGI::Application';


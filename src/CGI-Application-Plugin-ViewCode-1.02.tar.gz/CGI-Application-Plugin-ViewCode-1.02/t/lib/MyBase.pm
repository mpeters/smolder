package MyBase;
use base 'CGI::Application';

=head1 NAME MyBase

=cut

1;

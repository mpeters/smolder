
package MyApp::Test2;

sub echo {
	my $server = shift;
	my ($arg)  = @_;
	return $arg;
}

1;

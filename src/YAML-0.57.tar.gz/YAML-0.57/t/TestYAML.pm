package t::TestYAML;
use Test::YAML 0.51 -Base;

$Test::YAML::YAML = 'YAML';

$^W = 1;

package ApachePlugin::CGI;
use strict;
use base 'CGI::Application';
use CGI::Application::Plugin::Apache qw(:all);

1;


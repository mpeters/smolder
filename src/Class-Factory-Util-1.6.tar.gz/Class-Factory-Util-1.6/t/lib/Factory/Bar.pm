package Factory::Bar;

1;

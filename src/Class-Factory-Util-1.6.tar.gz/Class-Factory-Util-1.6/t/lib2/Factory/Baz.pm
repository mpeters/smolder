package Factory::Baz;

1;

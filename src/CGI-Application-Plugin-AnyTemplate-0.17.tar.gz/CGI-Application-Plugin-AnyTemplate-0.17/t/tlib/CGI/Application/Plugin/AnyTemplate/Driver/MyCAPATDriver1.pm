
package CGI::Application::Plugin::AnyTemplate::Driver::MyCAPATDriver1;
use base 'CGI::Application::Plugin::AnyTemplate::Base';

1;
